<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class Document extends CI_Controller
{ 
	public function __construct()
	{
		parent:: __construct();
	}
 
	
    public function view_details()
	{
		
         $data['image'] = $this->Document->getRows();
         $id = $this->uri->segment(3);
         $data['folder'] = $this->Project->getData($id);
		if($this->session->has_userdata('user')!=NULL)
		{
			    $data['images']=$this->Document->get_All_Images($this->session->userdata('user'));
				//$data['project_id']=$this->uri->segment(3);
				$this->layout->view('document/document',$data);
			
		}
		else
		{
			redirect('dashboard');
		}
	}
	
public function file_upload()
	{
        //$data['image'] = $this->Project->getRows();
		        //$data['docfile'] = $this->Document->getRowss();
		        $id = $this->uri->segment(3);
                $data['folder'] = $this->Project->getData($id);
				$data['file']=$this->Document->getDocImages($this->session->userdata('user'),$id);
				$this->layout->view('document/folder',$data);
				
		
	}

	public function post_add_image()
    {
    	$errorUploadType = "";
    	$statusMsg = "";
    	if($_POST!=NULL)
    	{
    		if($this->session->has_userdata('user')!=false)
    		{
    			if(!empty($_FILES['files']['name']) && count(array_filter($_FILES['files']['name'])) > 0)
    			{
    				//$type=$this->input->post('type');
    				$project_id=$this->uri->segment(3);
    				//$sub_task_id=$this->uri->segment(4);
    				//$tagname = $this->Project->getTagName($project_id);
    				//$previous_image_tag=$this->Project->lastImageTag($project_id);
    				//$tag_number=$this->Project->tagNumber($previous_image_tag);
    				$filesCount = count($_FILES['files']['name']);
    				for($i = 0; $i < $filesCount; $i++)
    				{
						$_FILES['file']['name']     = $_FILES['files']['name'][$i]; 
						$_FILES['file']['type']     = $_FILES['files']['type'][$i]; 
						$_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i]; 
						$_FILES['file']['error']     = $_FILES['files']['error'][$i]; 
						$_FILES['file']['size']     = $_FILES['files']['size'][$i]; 
						$uploadPath = 'uploads/'; 
						$config['upload_path'] = $uploadPath; 
						$config['allowed_types'] = 'jpg|jpeg|png|gif|pdf|doc|docx'; 
						$config['max_size'] = ""; // Can be set to particular file size , here it is 2 MB(2048 Kb)
                        $config['max_height'] = "";
                        $config['max_width'] = "";
						$this->load->library('upload', $config); 
						$this->upload->initialize($config);

						if($this->upload->do_upload('file'))
						{
	                        $fileData = $this->upload->data(); 
	                        $uploadData[$i]['image_name'] = $fileData['file_name']; 
	                        $uploadData[$i]['type']=$fileData['file_type'];
	                        //$uploadData[$i]['project'] = $project_id;
	                        //$uploadData[$i]['sub_task_id'] = $sub_task_id;
	                        //$uploadData[$i]['type'] = $type;
	                        //$uploadData[$i]['tag'] = $tagname.''.($tag_number+1);
	                        $uploadData[$i]['created_by'] = $this->session->userdata('user');
	                        $uploadData[$i]['status'] = $this->session->userdata('user');
	                        $uploaddata[$i]['date']=date("y-m-d");
	                        $uploadData[$i]['created_at'] = date("Y-m-d H:i:s");
							$uploadData[$i]['modified_at'] = date("Y-m-d H:i:s"); 
							$uploadData[$i]['file_assign_id'] = $this->uri->segment(3);
							//$tag_number++;
						}
						else
						{
							$errorUploadType .= $_FILES['file']['name'].' | ';
						}

						$errorUploadType = !empty($errorUploadType)?'<br/>File Type Error: '.trim($errorUploadType, ' | '):''; 
					}

						if(!empty($uploadData))
						{
							$insert = $this->Document->inserts($uploadData); 
							$id=$this->uri->segment(3);
							if($insert==true)
							{
								redirect('document/file_upload/'.$id);
							}
							else
							{
								$errorUploadType = 'Some problem occurred, please try again.';
							}					
						}
						else
						{
							$statusMsg = "Sorry, there was an error uploading your file.".$errorUploadType;
						}
    			}
    			else
    			{
    				echo "Please Select File to Upload";
    			}
    		}
    		else
    		{
    			redirect('dashboard');
    		}
    	}
    	else
    	{
    		redirect('dashboard');
    	}
    }
     function dragDropUpload(){ 
        if(!empty($_FILES)){ 
            // File upload configuration 
            $uploadPath = 'uploads/'; 
            $config['upload_path'] = $uploadPath; 
            $config['allowed_types'] = '*'; 
             
            // Load and initialize upload library 
            $this->load->library('upload', $config); 
            $this->upload->initialize($config); 
             
            // Upload file to the server 
            if($this->upload->do_upload('file')){ 
                $fileData = $this->upload->data(); 
                $uploadData[$i]['image_name'] = $fileData['file_name'];
                $uploadData[$i]['type']=$fileData['file_type'];
	            $uploadData[$i]['created_by'] = $this->session->userdata('user');
	            $uploadData[$i]['status'] = $this->session->userdata('user');
	            //$uploaddata[$i]['date']=date("y-m-d");
	            $uploadData[$i]['created_at'] = date("Y-m-d H:i:s");
	            $uploadData[$i]['modified_at'] = date("Y-m-d H:i:s");              
                 
                // Insert files info into the database 
                //$insert = $this->Document->inserts($uploadData); 
            } 
            if(!empty($uploadData))
						{
							$insert = $this->Document->inserts($uploadData); 
							if($insert==true)
							{
								redirect('document/file_upload/');
							}
							else
							{
								$errorUploadType = 'Some problem occurred, please try again.';
							}					
						}
						else
						{
							$statusMsg = "Sorry, there was an error uploading your file.".$errorUploadType;
						}
        } 
    } 
}
