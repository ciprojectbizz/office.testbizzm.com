<?php
// PHP program to pop an alert
// message box on the screen
  
// Display the alert box 
echo '<script>alert("File uploaded successfully")</script>';
  
?>
<a href="<?= base_url('project/view_details/'.$project_id)?>">click here</a>