  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper" style="margin-left: 0;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Projects</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">

            <div class="card" style="border-radius: 15px">
              <div class="card-header">
                <a href="<?=base_url('project/add_project')?>"><button class="btn btn-primary" data-toggle="tooltip" title="Add Project"><i class="fa fa-plus"></i></button></a>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-striped">
                  <thead style="background-color:#023047; color: #fff">
                  <tr>
                    <th>Name</th>
                    <th>Company Name</th>
                    <th>Assign To</th>
                    <th>Expected Delivery</th>
                    <th>Created By</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php foreach($projects as $project): ?>
                      <tr style="background-color: #fff; color: #000">
                        <td><i class="fa fa-laptop-code"></i> <?= $project['project_name']?></td>
                        <td><i class="fa fa-building"></i> <?= $project['company_name']?></td>
                        <td><i class="fa fa-user"></i> <?= $project['project_manager_name']?></td>
                        <td><i class="fa fa-calendar-day"></i> <?= $project['expected_delivery']?></td>
                        <td><?= $project['employee_name']?></td>
                        <td><a href="<?= base_url('project/tasks/'.$project['id'])?>" class="btn btn-default" style="background-color: #264653; color:#fff" data-toggle="tooltip" title="View Tasks"><i class="fa fa-eye"></i></a></td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


