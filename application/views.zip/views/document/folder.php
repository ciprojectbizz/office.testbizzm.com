<!-- Button trigger modal -->
<!-- Content Wrapper. Contains page content -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/dist/js/dropzone/dropzone.min.css" />
<script type="text/javascript" src="<?php echo base_url(); ?>assets/dist/js/dropzone/dropzone.min.js"></script>
  <div class="content-wrapper" style="margin-left: 0;">
      <!-- Content Header (Page header) -->
      <section class="content-header">
          <div class="container-fluid">
              <div class="row mb-2">
                  <div class="col-sm-6">
                      <h1>Add File</h1>
                  </div>
              </div>
          </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">
          <div class="container-fluid">
              <div class="row">
                  <div class="col-12">

                      <div class="card" style="border-radius: 15px">
                          <div class="card-header">

                          </div>
                          <!-- /.card-header -->
                          <div class="card-body">
                            <h4>File upload</h4>
                            <form id="" action="<?= base_url('document/post_add_image/'.$this->uri->segment(3)) ?>" method="post"
                          enctype="multipart/form-data">
                          <input type="file" class="" id="" name="files[]" multiple required=""
                              style="margin-top: 10px;">

                  </div>
                  
                  <input class="btn btn-success" type="submit" name="fileSubmit" style="width: 15%" value="UPLOAD" />
                  </form>
                  <!-- <form action="<?= base_url('document/dragDropUpload/' . $project_id); ?>" class="dropzone" method="post"></form> -->
                    <section>
                 <?php if(!empty($file)){ foreach($file as $files):if($files['type']=='image/png') { ?>
                    <figure class="figure">
                        <img src="<?= base_url('uploads/'.$files['image_name'])?>" width="200" height="150" style="object-fit:cover;margin:35px"><figcaption class="figcaption text-center"><?=$files['image_name']?>
                         <a href="<?php echo base_url().'project/download/'.$files['id']; ?>" class=""><i class="fa fa-download" style="color: gray"></i></a></figcaption>
                    </figure>
                    <?php } elseif($files['type']=='image/jpg') { ?>
                      <figure class="figure">
                        <img src="<?= base_url('uploads/'.$image['image_name'])?>" width="200" height="150" style="object-fit:cover;margin:35px"><figcaption class="figcaption text-center"><?=$files['image_name']?>
                         <a href="<?php echo base_url().'project/download/'.$files['id']; ?>" class=""><i class="fa fa-download" style="color: gray"></i></a></figcaption>
                    </figure>
                    <?php } elseif($files['type']=='image/jpeg') { ?>
                       <figure class="figure">
                        <img src="<?= base_url('uploads/'.$files['image_name'])?>" width="200" height="150" style="object-fit:cover;margin:35px"><figcaption class="figcaption text-center"><?=$files['image_name']?>
                         <a href="<?php echo base_url().'project/download/'.$files['id']; ?>" class=""><i class="fa fa-download" style="color: gray"></i></a></figcaption>
                    </figure>
                     <?php } elseif($files['type']=='image/gif') { ?>
                       <figure class="figure">
                        <img src="<?= base_url('uploads/'.$files['image_name'])?>" width="200" height="150" style="object-fit:cover;margin:35px"><figcaption class="figcaption text-center"><?=$files['image_name']?>
                         <a href="<?php echo base_url().'project/download/'.$files['id']; ?>" class=""><i class="fa fa-download" style="color: gray"></i></a></figcaption>
                    </figure>
                   <?php } elseif($files['type']=='application/pdf') { ?>

                    <figure class="figure">
                      <a href="<?= base_url('uploads/'.$files['image_name'])?>"><i class="fa fa-file-pdf" style="font-size:140px;color:red; margin: 35px"></i></a>
                        <!--img src="<?= base_url('uploads/'.$image['image_name'])?>" width="200" height="150" style="object-fit:cover;margin:35px"--><figcaption class="figcaption text-center"><?=$files['image_name']?>
                         <a href="<?php echo base_url().'project/download/'.$files['id']; ?>" class=""><i class="fa fa-download" style="color: gray"></i></a></figcaption>
                    </figure>
                    <?php } elseif($files['type']=='application/vnd.openxmlformats-officedocument.wordprocessingml.document') { ?>

                    <figure class="figure">
                      <a href="<?= base_url('uploads/'.$files['image_name'])?>"><i class="fa fa-file-word" style="font-size:140px;color:lightblue; margin: 35px"></i></a>
                        <!--img src="<?= base_url('uploads/'.$image['image_name'])?>" width="200" height="150" style="object-fit:cover;margin:35px"--><figcaption class="figcaption text-center"><?=$files['image_name']?>
                         <a href="<?php echo base_url().'project/download/'.$files['id']; ?>" class=""><i class="fa fa-download" style="color: gray"></i></a></figcaption>
                    </figure>
                    
                    <?php } endforeach;} ?>
                    
                </section>

                          </div>
                          <!-- /.card-body -->
                      </div>
                      <!-- /.card -->
                  </div>
                  <!-- /.col -->
              </div>
              <!-- /.row -->
          </div>
          <!-- /.container-fluid -->
      </section>
      <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

