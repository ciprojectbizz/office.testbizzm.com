 <div class="content-wrapper" style="margin-left: 0;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Documents</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">

            <div class="card">
              <div class="card-header">
                <!--a href="<?= base_url('project/add_image/'.$project_id)?>"><button class="btn btn-success">Add Images</button></a>
               <a href="<?= base_url('project/downloadWord/'.$project_id)?>"><button class="btn btn-primary">Download as Word Document</button></a>
                <a href="<?= base_url('project/downloadPdf/'.$project_id)?>"><button class="btn btn-danger">Download as PDF</button></a> 
              </div>
              </card-header -->
              <div class="card-body">
                <div style="display:inline-block;">
                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#create_folder">Create</button>
                      <?php foreach($folder as $folders): ?>
                     <figure class="figure">
                      <a href="<?= base_url('document/file_upload/'.$folders['id'])?>"><i class="fa fa-folder" style="font-size:50px;color:#f6bd60; margin-left: 20px"></i>
                        <figcaption class="figcaption text-center"><?=$folders['folder_name']?>
                      </a>
                        </figcaption>
                      </figure>
                       
                      
                    <?php endforeach; ?>
               
                </div>
                 <section>
                 <?php if(!empty($images)){ foreach($images as $image):if($image['type']=='image/png') { ?>
                    <figure class="figure">
                        <img src="<?= base_url('uploads/'.$image['image_name'])?>" width="200" height="150" style="object-fit:cover;margin:35px"><figcaption class="figcaption text-center"><?=$image['image_name']?>
                         <a href="<?php echo base_url().'project/download/'.$image['id']; ?>" class=""><i class="fa fa-download" style="color: gray"></i></a></figcaption>
                    </figure>
                    <?php } elseif($image['type']=='image/jpg') { ?>
                      <figure class="figure">
                        <img src="<?= base_url('uploads/'.$image['image_name'])?>" width="200" height="150" style="object-fit:cover;margin:35px"><figcaption class="figcaption text-center"><?=$image['image_name']?>
                         <a href="<?php echo base_url().'project/download/'.$image['id']; ?>" class=""><i class="fa fa-download" style="color: gray"></i></a></figcaption>
                    </figure>
                    <?php } elseif($image['type']=='image/jpeg') { ?>
                       <figure class="figure">
                        <img src="<?= base_url('uploads/'.$image['image_name'])?>" width="200" height="150" style="object-fit:cover;margin:35px"><figcaption class="figcaption text-center"><?=$image['image_name']?>
                         <a href="<?php echo base_url().'project/download/'.$image['id']; ?>" class=""><i class="fa fa-download" style="color: gray"></i></a></figcaption>
                    </figure>
                     <?php } elseif($image['type']=='image/gif') { ?>
                       <figure class="figure">
                        <img src="<?= base_url('uploads/'.$image['image_name'])?>" width="200" height="150" style="object-fit:cover;margin:35px"><figcaption class="figcaption text-center"><?=$image['image_name']?>
                         <a href="<?php echo base_url().'project/download/'.$image['id']; ?>" class=""><i class="fa fa-download" style="color: gray"></i></a></figcaption>
                    </figure>
                   <?php } elseif($image['type']=='application/pdf') { ?>

                    <figure class="figure">
                      <a href="<?= base_url('uploads/'.$image['image_name'])?>"><i class="fa fa-file-pdf" style="font-size:140px;color:red; margin: 35px"></i></a>
                        <!--img src="<?= base_url('uploads/'.$image['image_name'])?>" width="200" height="150" style="object-fit:cover;margin:35px"--><figcaption class="figcaption text-center"><?=$image['image_name']?>
                         <a href="<?php echo base_url().'project/download/'.$image['id']; ?>" class=""><i class="fa fa-download" style="color: gray"></i></a></figcaption>
                    </figure>
                    <?php } elseif($image['type']=='application/vnd.openxmlformats-officedocument.wordprocessingml.document') { ?>

                    <figure class="figure">
                      <a href="<?= base_url('uploads/'.$image['image_name'])?>"><i class="fa fa-file-word" style="font-size:140px;color:lightblue; margin: 35px"></i></a>
                        <!--img src="<?= base_url('uploads/'.$image['image_name'])?>" width="200" height="150" style="object-fit:cover;margin:35px"--><figcaption class="figcaption text-center"><?=$image['image_name']?>
                         <a href="<?php echo base_url().'project/download/'.$image['id']; ?>" class=""><i class="fa fa-download" style="color: gray"></i></a></figcaption>
                    </figure>
                    <?php } elseif($image['type']=='capture/image') { ?>
                      <figure class="figure">
                        <img src="<?= $image['image_name']?>" width="200" height="150" style="object-fit:cover;margin:35px"><figcaption class="figcaption text-center">image
                         <a href="<?php echo base_url().'project/download/'.$image['id']; ?>" class=""><i class="fa fa-download" style="color: gray"></i></a></figcaption>
                    </figure>
                    <?php } endforeach;} ?>
                </section>
                 
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
  </div>
 <div class="modal" id="create_folder">
          <div class="modal-dialog">
              <div class="modal-content">

                  <!-- Modal Header -->
                  <div class="modal-header">
                      <h4 class="modal-title">Create Folder</h4>
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                  </div>

                  <!-- Modal body -->
                  <div class="modal-body">
                      <div class="modal-form">
                        <form method="POST" action="<?= base_url('project/folder_create') ?>">
                          <p>Enter Folder Name</p>
                        
                              <input type="text" name="create_folder">
                              <input type="submit" class="btn btn-success" value="submit">
                        </form> 
                      </div>
                      
                  </div>

                  <!-- Modal footer -->
                  <div class="modal-footer">
                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                  </div>

              </div>
          </div>
      </div> 
