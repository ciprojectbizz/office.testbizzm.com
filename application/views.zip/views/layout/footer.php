  <footer class="main-footer">
    <strong>Copyright &copy; 2021 Developed By <a href="https://www.bizzmanweb.com/">BizzmanWeb</a></strong> 
  </footer>