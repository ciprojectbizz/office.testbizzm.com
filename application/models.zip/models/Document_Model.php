<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class Document_Model extends CI_Model
{
    function insert($table,$data)
    {
        $this->db->insert($table,$data);
        //$this->db->set($data);
        return $this->db->insert_id();
       
    }
    function get_All_Images($userId)
    {
        $this->db->select('image.*,projects.name as project_name');
        $this->db->from('image');
        $this->db->join('projects','projects.id=image.project');
        $this->db->where('image.created_by',$userId);
        
        return $this->db->get()->result_array();
    }
     function storecaptureimage($data)
   {
        $insert = $this->db->insert('image',$data); 
        return true;
   }
    function createfolder($data)
   {
        $insert = $this->db->insert('file_assign',$data); 
        return true;
   }
   
    function getRows($params = array()){
        $this->db->select('*');
        $this->db->from('image');
        $this->db->where('status','1');
        $this->db->order_by('created_at','desc');
        if(array_key_exists('id',$params) && !empty($params['id'])){
            $this->db->where('id',$params['id']);
            //get records
            $query = $this->db->get();
            $result = ($query->num_rows() > 0)?$query->row_array():FALSE;
        }else{
            //set start and limit
            if(array_key_exists("start",$params) && array_key_exists("limit",$params)){
                $this->db->limit($params['limit'],$params['start']);
            }elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params)){
                $this->db->limit($params['limit']);
            }
            //get records
            $query = $this->db->get();
            $result = ($query->num_rows() > 0)?$query->result_array():FALSE;
        }
        //return fetched data
        return $result;
    }
    function inserts($data = array())
    {
        $insert = $this->db->insert_batch('docfile',$data); 
        return true;
    }
    function getDocImages($userId,$id)
    {
        $this->db->select('docfile.*');
        $this->db->join('file_assign','file_assign.id = docfile.file_assign_id');
        $this->db->where('docfile.created_by',$userId);
        $this->db->where('docfile.file_assign_id',$id);
        $this->db->from('docfile');
        return $this->db->get()->result_array();
    }
  function getRowss($id = ''){ 
        $this->db->select('docfile.*'); 
        $this->db->from('docfile'); 
        if($id){ 
            $this->db->where('id',$id); 
            $query = $this->db->get(); 
            $result = $query->row_array(); 
        }else{ 
            $this->db->order_by('created_at','desc'); 
            $query = $this->db->get(); 
            $result = $query->result_array(); 
        } 
         
        return !empty($result)?$result:false; 
    } 
     
    /* 
     * Insert file data into the database 
     * @param array the data for inserting into the table 
     */ 
     /*function insertss($data = array()){ 
        $insert = $this->db->insert('docfile', $data); 
        return $insert?true:false; 
    } */
    function getImageData($imageId)
    {
        $this->db->select('image_name');
        $this->db->from('image');
        $this->db->where('id',$imageId);
        $query=$this->db->get();
        $row=$query->row_array();
        return $row['image_name'];
    }
}